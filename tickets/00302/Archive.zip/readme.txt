There was a thread a while back called, "How to implement new Haardt & Madau UV background? Problem with units."  As a result, I (eventually) produced updated files for the HM12 background for Cloudy.  I'm attaching them here in case they're useful to you.  If you compile Cloudy with this new parse_table.cpp and include the new .dat you will be able to use the HM12 background in the same way you use the HM05 background except it will not accept the quasar keyword (there is only one HM12 model and it includes quasars).  For example you can do,

table hm12 redshift 3.0

in your cloudy config file.  Below are descriptions of the attached files.

hm12_cloudy.dat
the cloudy formatted data file.  place this in the Cloudy data directory

parse_table.cpp
updated source file that includes a function to read the new background data.  use this file to replace the old file in the cloudy source directory

UVB.out
the original data from the HM12 model.   (just for reference)

write_hm12_cloudy.py
script that creates hm12_cloudy.dat from UVB.out (just for reference)




On Sat, Jul 19, 2014 at 9:14 PM, Britton Smith brittonsmith@gmail.com [cloudy_simulations] <cloudy_simulations@yahoogroups.com> wrote:

     

    Hi there,

    I wrote a script to take the raw HM12 data and turn them into tabulated spectrum files readable by Cloudy.  If you're interested, I can send it to you.  You can contact me off-list at brittonsmith@gmail.com if you'd like it.

    Britton


    On Fri, Jul 18, 2014 at 1:25 PM, jmcewen314@gmail.com [cloudy_simulations] <cloudy_simulations@yahoogroups.com> wrote:

         

        I want to use the new HM12 background with Cloudy instead of HM05 or HM96.  My plan was to download the new Haardt-Madau background, convert to the units used in HM05, and copy & paste into HM05. 


        This does not seem to be working.  For one I getting an error requesting that the wavelength be in increasing order.  I already did that, they are in increasing order.  


        Has anyone done this?  


        thanks for you time.  





-- 
-- 
Gabriel Altay, PhD
Center for Relativistic Astrophysics
Georgia Institute of Technology, Physics Department
837 State Street, Atlanta, GA, 30332
phone: +01 404 205 9795
url: http://cosmo.gatech.edu/?page_id=1075