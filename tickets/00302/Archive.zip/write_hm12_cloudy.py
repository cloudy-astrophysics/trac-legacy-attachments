"""

This python module reads the file UVB.out which describes the Haardt and Madau
2012 UV background model.  It then writes it back out in a format that 
Cloudy can use. 

http://www.ucolick.org/~pmadau/CUBA/Media/UVB.out

http://adsabs.harvard.edu/abs/2012ApJ...746..125H

""" 

import math
import numpy as np



JNU_MIN = 1.0e-60
ANG_FRAC = 1.0e-2
MAGIC_NUMBER = 736297

fout = 'hm12_cloudy.dat'



def is_number(s):
    """ check if a string is a number """ 
    try:
        float(s)
        return True
    except ValueError:
        return False



def to_precision(x,p):
    """
    from Randle Taylor 
    http://randlet.com/blog/python-significant-figures-format

    returns a string representation of x formatted with a precision of p
    """

    x = float(x)

    if x == 0.:
        return "0." + "0"*(p-1)

    out = []

    if x < 0:
        out.append("-")
        x = -x

    e = int(math.log10(x))
    tens = math.pow(10, e - p + 1)
    n = math.floor(x/tens)

    if n < math.pow(10, p - 1):
        e = e -1
        tens = math.pow(10, e - p+1)
        n = math.floor(x / tens)

    if abs((n + 1.) * tens - x) <= abs(n * tens -x):
        n = n + 1

    if n >= math.pow(10,p):
        n = n / 10.
        e = e + 1

    m = "%.*g" % (p, n)

    if e < -2 or e >= p:
        out.append(m[0])
        if p > 1:
            out.append(".")
            out.extend(m[1:p])
        out.append('e')
        if e > 0:
            out.append("+")
        out.append(str(e))
    elif e == (p -1):
        out.append(m)
    elif e >= 0:
        out.append(m[:e+1])
        if e+1 < len(m):
            out.append(".")
            out.extend(m[e+1:])
    else:
        out.append("0.")
        out.extend(["0"]*-(e+1))
        out.append(m)

    return "".join(out)










# read original HM12 file
#------------------------------------------------------------

fname = 'UVB.out' 
f = open( fname, 'r' )
lines = f.readlines()
f.close()



# open output file
#=============================================================
fname = fout
f = open( fname, 'w' )


# write comment lines unchanged (don't write lines that describe
# the format as we are changing it)
#------------------------------------------------------------------
for line in lines:

    if line.strip().startswith('#'):

        if line.strip().startswith('# The following 3 lines are column'):
            continue
        if line.strip().startswith('# Line 1: contains 60 fields'):
            continue
        if line.strip().startswith('# Lines 2 through 576: the first'):
            continue
        if line.strip().startswith('# J (in units of ergs/s/cm^2/Hz/sr)'):
            continue

        f.write( line.strip()+'\n' )


# write extra comments
#------------------------------------------------------------------
f.write( '# ** changes to original UVB.out file from CUBA website ** \n' )
f.write( '# http://www.ucolick.org/~pmadau/CUBA/Media/UVB.out \n' )
f.write( '# redshifts reformatted and highest redshift removed \n' )
f.write( '# duplicate angstrom entries are nudged \n' )
f.write( '# Jnu floor set to ' + str(JNU_MIN) + ' \n' )


# write magic number
#------------------------------------------------------------------
f.write( ' '+str(MAGIC_NUMBER)+'\n' )


# the first non-empty line that is all numbers is the redshifts.  
# note we don't write the last redshift as all the entries in Jnu
# column for that redshift are zero. 
#------------------------------------------------------------------
for line in lines:

    bools = []
    for word in line.split( ' ' ):
        bools.append( is_number(word) )
    bools = np.array( bools[1:] )

    # skip empty lines
    if bools.size==0: 
        continue

    # check if all entries are numbers
    if np.all( bools==True ):
        print 'first line!' 
        print line


        # change from exponential format
        new_line = 'wavelength(A)' 
        for word in line.split(' ')[1:-1]:    
            w = word.rstrip('\n')
            print 'word=', w, to_precision(float(w),4)
            new_line = new_line + '  z=' + to_precision(float(w),4)

        f.write( new_line+'\n' )
        break

# write angstrom and Jnu rows
#------------------------------------------------------------------

# find duplicate angstrom entries

fname = 'UVB.out'
dat = np.loadtxt( fname )

z = dat[0,:-1]
Nz = z.size
Nnu = dat.shape[0]-1
Ang = np.zeros( Nnu )
Jnu = np.zeros( (Nnu, Nz) )
for i in range(1,Nnu+1):
    Ang[i-1] = dat[i,0]
    Jnu[i-1,:] = dat[i,1:]


# nudge duplicate angstrom entries

Ang_ratio = Ang[1:] / Ang[:-1]
for i in range( Ang_ratio.size ):

    if Ang_ratio[i] == 1.0:

        Alo = Ang[i]
        Ahi = Ang[i+1]

        dA_lo = Ang[i] - Ang[i-1]
        dA_hi = Ang[i+2] - Ang[i+1]

        print i, Alo, Ahi
        print 'dA_lo: ', dA_lo
        print 'dA_hi: ', dA_hi
        print

        Alo_new = Alo - ANG_FRAC * dA_lo
        Ahi_new = Ahi + ANG_FRAC * dA_hi

        Ang[i] = Alo_new
        Ang[i+1] = Ahi_new


# enforce a minimum Jnu instead of zero

indx = np.where( Jnu < JNU_MIN )
Jnu[indx] = JNU_MIN


# write values to file

for i in range(Ang.size):
    a = str( Ang[i] )
    f.write( a )
    for j in Jnu[i,:]:
        f.write( '  '+str(j) )
    f.write('\n')




f.close()

